"""hist: 1D histograms of per-event arrays.

Each DataFrame row holds the values of one sample (array cells); the first
row of every (panel, hue) selection is histogrammed. Several ``-x`` columns
are first combined point by point with ``--hist_combine`` (sum, mean,
subtract, relative = (a - b) / last, absolute_relative, rms). Panels come
from ``--variables``, colours from ``--hue``; ``--hue Config``/``Name`` draws
the loaded configs/names together with the config mappings. Every hue of a
panel shares one set of bin edges, spanning all of them; entries outside
(``--rangex``, ``--percentile``) are reported and, with ``--flow``, hinted at
or added to the edge bins.

``--hist_type kde`` draws a Gaussian kernel density estimate instead (a
smooth line with a band of its pointwise standard error), ``ecdf`` the
empirical cumulative distribution (a step with its binomial band);
``--cumulative`` accumulates a histogram. ``--rug`` marks the values along
the x axis, ``--ridge`` stacks the hue values on their own baselines.
"""

import matplotlib
import numpy as np
from matplotlib.colors import to_rgba
from matplotlib.transforms import blended_transform_factory, offset_copy
from rich import print as rprint

from .. import intervals, style
from ..args import add_common_args, map_iterable_color, map_iterable_label, resolve_axis_label
from ..encodings import HueColormap, add_hue_cmap_args, add_legend_args
from ..format import make_config_color_and_style_from_args, make_config_label_from_args, make_subtitle_from_args
from ..io import import_data, prepare_import
from ..hue_colors import avoid_registered, registered_color
from ..palettes import ColorAllocator
from ..panel_lines import add_panel_line_args, draw_panel_lines, panel_rangex, resolve_panel_lines
from ..panels import add_title_and_note, create_panels, draw_overlays, save
from ..plot import _resolve_plot_style, apply_legend_style, apply_tick_formatter
from ..selection import filter_dataframe
from . import _base

KIND = "hist"
COMBINE = ["sum", "mean", "subtract", "relative", "absolute_relative", "rms"]
FLOW = ["none", "hint", "show"]
HIST_TYPES = ["hist", "kde", "ecdf"]
RUG_MAX = 5000  # values drawn by --rug (a sample of them past this)
ECDF_POINTS = 2000  # an ECDF of more values is drawn on a grid of this many points


def build_parser():
    parser = _base.make_parser(KIND, "1D histograms of array columns, one line per --hue value.")
    add_common_args(
        parser,
        [
            "datafile", "configs", "names", "variables", "x", "iterable", "reduce", "select",
            "save_values", "remove_value", "filename_select", "filename_suffix", "bins", "percentile",
            "labelx", "labely", "labelz", "logx", "logy", "rangex", "rangey", "title", "output",
            "subfolder", "horizontal", "horizontal_label", "horizontal_style", "horizontal_color", "horizontal_label_pos",
            "vertical", "vertical_label", "vertical_style", "vertical_color", "point", "point_label",
            "vertical_band", "vertical_band_label", "vertical_band_color", "horizontal_band",
            "horizontal_band_label", "horizontal_band_color",
            "note", "debug", "density", "confidence_level", "error_label", "no_error",
        ],
        overrides={
            "datafile": {"required": True},
            "x": {"nargs": "+", "required": True, "help": "Array column(s) histogrammed (several are combined)"},
            "density": {"help": "Normalise each histogram to unit area (also when --labely is 'Density')"},
        },
    )
    add = parser.add_argument
    add("--hist_combine", type=str, default=None, choices=COMBINE,
        help="How several -x columns are combined point by point.")
    add("--weight", "-w", type=str, default=None, help="Array column of per-entry weights.")
    add("--flow", type=str, default="none", choices=FLOW,
        help="Entries outside the range: none (dropped), hint (a marker beyond the outer edge), "
             "show (added to the first/last bin). Their number is printed in every mode.")
    add("--iterable_mapping", "--hue_mapping", dest="iterable_mapping", type=str, default=None,
        help="Mapping renaming the hue values in the legend.")
    add("--iterable_color_mapping", "--hue_color_mapping", dest="iterable_color_mapping", type=str, default=None,
        help="Mapping giving the colour of each hue value.")
    add("--iterable_order", nargs="+", type=str, default=None,
        help="Draw/legend order of the hue values (listed first, others keep data order).")
    add("--data_hue", "--overlay", nargs="+", default=None, metavar="VALUE",
        help="Hue values drawn as data: points at the bin centres with Poisson (Garwood) error bars, or "
        "sqrt(sum of squared weights) with --weight, in the ink colour, first in the legend. The other hue "
        "values stay step histograms.")
    add("--errory_type", type=str, default=None, choices=["poisson"],
        help="Error bars instead of bands on every histogram: Poisson (Garwood) intervals of the bin counts, or "
        "sqrt(sum of squared weights) with --weight (data points always have them).")
    add("--overlay_gaussian", nargs="*", type=float, default=None, metavar=("MU", "SIGMA"),
        help="Draw a Gaussian over the histogram, scaled to the first series' entries: the unit normal (no "
        "values; for pull distributions) or MU SIGMA.")
    add("--hist_type", type=str, default="hist", choices=HIST_TYPES,
        help="hist: step histograms; kde: Gaussian kernel density estimates (smooth lines with a band of their "
        "pointwise standard error) of unit area, or counts per bin when --data_hue points share the axes; "
        "ecdf: empirical cumulative distributions (steps from 0 to 1 with a binomial band). --data_hue values "
        "stay histogram points with kde.")
    add("--bw", type=str, default="scott", metavar="WIDTH",
        help="With --hist_type kde: the kernel width in units of x, or scott (default) or silverman for the "
        "rules of thumb (from the sample's standard deviation and size).")
    add("--cumulative", nargs="?", const="forward", default=None, choices=["forward", "reverse"],
        help="Accumulate the histogram: forward (entries up to each bin's upper edge) or reverse (from each "
        "bin's lower edge up: the survival above a cut); with --density, as fractions of the entries.")
    add("--rug", action="store_true", default=False,
        help="Mark every value with a short tick along the x axis, in the series colour, fainter the more there "
        f"are (a sample of {RUG_MAX} when there are more).")
    add("--ridge", nargs="?", type=float, const=0.5, default=None, metavar="OVERLAP",
        help="Ridgeline: each hue value on its own baseline, the first on top, its name as the y tick label "
        "(no legend); the curves are filled and scaled to reach OVERLAP (default 0.5) into the row above.")
    add_legend_args(parser)
    add_hue_cmap_args(parser)
    add_panel_line_args(parser, horizontal=False)
    _base.add_output_args(parser)
    return parser


def main(argv=None):
    return _base.main(__import__(__name__, fromlist=["run"]), argv)


def combined_values(subset, args):
    """Values of the first row, the -x columns combined by --hist_combine."""
    x = np.asarray(subset[args.x[0]].values[0], dtype=float)
    if len(args.x) == 1:
        return x
    op = args.hist_combine or "subtract"
    for column in args.x[1:]:
        other = np.asarray(subset[column].values[0], dtype=float)
        if op in ("mean", "sum"):
            x = x + other
        elif op in ("subtract", "relative", "absolute_relative"):
            x = x - other
        elif op == "rms":
            x = x**2 + other**2
    last = np.asarray(subset[args.x[-1]].values[0], dtype=float)
    if op == "mean":
        x = x / len(args.x)
    elif op == "relative":
        x = x / last
    elif op == "absolute_relative":
        x = np.abs(x) / last
    elif op == "rms":
        x = np.sqrt(x / len(args.x))
    return x


def _histogram_range(samples, args, idx):
    """Range of one panel: --panel_rangex, --rangex, else --percentile or the
    extremes of all its hue samples together."""
    rangex = panel_rangex(args, idx)
    if rangex is not None:
        return tuple(rangex)
    if args.rangex is not None:
        return tuple(args.rangex)
    x = np.concatenate(samples)
    if args.percentile is None:
        return float(np.min(x)), float(np.max(x))
    return float(np.percentile(x, args.percentile[0])), float(np.percentile(x, args.percentile[1]))


def histogram(x, edges, weights=None, density=False, flow="none"):
    """(counts, underflow, overflow) of *x* in *edges*. ``flow="show"`` adds the
    outside weights to the first/last bin; density normalises what is drawn."""
    counts, under, over, _ = histogram_with_errors(x, edges, weights, density=density, flow=flow)
    return counts, under, over


def histogram_with_errors(x, edges, weights=None, density=False, flow="none"):
    """:func:`histogram` plus the error of each bin, sqrt(sum of squared
    weights), scaled like the counts."""
    weights = np.ones_like(x) if weights is None else weights
    counts, _ = np.histogram(x, bins=edges, weights=weights)
    variance, _ = np.histogram(x, bins=edges, weights=weights**2)
    counts, variance = counts.astype(float), variance.astype(float)
    outside_low, outside_high = x < edges[0], x > edges[-1]
    under, over = float(np.sum(weights[outside_low])), float(np.sum(weights[outside_high]))
    if flow == "show":
        counts[0] += under
        counts[-1] += over
        variance[0] += float(np.sum(weights[outside_low] ** 2))
        variance[-1] += float(np.sum(weights[outside_high] ** 2))
    errors = np.sqrt(variance)
    if density:
        total = np.sum(counts)
        if total > 0:
            scale = 1.0 / (total * np.diff(edges))
            counts, errors = counts * scale, errors * scale
    return counts, under, over, errors


def bin_errors(x, edges, weights=None, density=False, flow="none", cl=intervals.ONE_SIGMA):
    """2xN (below, above) errors of the drawn bin contents: the Garwood
    interval of the counts, or sqrt(sum of squared weights) with weights;
    scaled like the counts with density."""
    raw, _, _, sumw2 = histogram_with_errors(x, edges, weights, density=False, flow=flow)
    if weights is None:
        low, high = intervals.garwood(raw, cl)
        errors = np.vstack([raw - low, high - raw])
    else:
        errors = np.vstack([sumw2, sumw2])
    if density:
        total = np.sum(raw)  # the same factor as histogram(density=True)
        errors = errors / (total * np.diff(edges)) if total > 0 else errors * 0
    return errors


def _draw_band(ax, counts, errors, edges, color, zorder=None, offset=0.0):
    """The 2xN (below, above) ``errors`` of a step histogram as a band at
    20% opacity behind its steps (rule U7), from its first to its last
    filled bin: empty bins beyond the sample would only show the upper limit
    of observing nothing. ``offset`` lifts it (a --ridge row's baseline)."""
    filled = np.flatnonzero(counts > 0)
    if not len(filled):
        return
    span = slice(filled[0], filled[-1] + 1)
    counts, errors = offset + np.asarray(counts)[span], np.asarray(errors)[:, span]
    ax.stairs(counts + errors[1], edges[span.start:span.stop + 1], baseline=counts - errors[0], fill=True,
              color=color, alpha=0.2, linewidth=0, **({} if zorder is None else {"zorder": zorder}))


def _draw_flow_hints(ax, counts, edges, under, over, color):
    """Small arrows just outside the outer edges, at the edge bins' height
    (mplhep's flow="hint")."""
    for outside, x, y, marker, dx in ((under, edges[0], counts[0], "<", -4), (over, edges[-1], counts[-1], ">", 4)):
        if outside > 0:
            ax.plot([x], [y], marker=marker, markersize=5, linestyle="none", color=color, clip_on=False,
                    transform=offset_copy(ax.transData, fig=ax.figure, x=dx, units="points"))


def _overlay_gaussian(ax, series, edges, density, args):
    """--overlay_gaussian: N(MU, SIGMA) (default the unit normal) over the
    panel, scaled to the entries of ``series`` inside the edges (or a density),
    dashed in ink, labelled with its parameters."""
    from scipy.stats import norm

    values = list(args.overlay_gaussian) + [0.0, 1.0][len(args.overlay_gaussian):]
    mu, sigma = values[0], values[1]
    _, x, weights = series
    inside = (x >= edges[0]) & (x <= edges[-1])
    entries = float(np.sum(weights[inside])) if weights is not None else float(np.sum(inside))
    width = float(np.mean(np.diff(edges)))
    grid = np.linspace(edges[0], edges[-1], 400)
    curve = norm.pdf(grid, mu, sigma) * (1.0 if density else entries * width)
    label = r"$\mathcal{N}(0, 1)$" if (mu, sigma) == (0.0, 1.0) else rf"$\mathcal{{N}}({mu:g}, {sigma:g})$"
    ax.plot(grid, curve, color=style.role("ink"), linestyle="--", linewidth=style.default_linewidth, label=label,
            zorder=4)


def kde_curve(x, weights, grid, bw="scott"):
    """(density, standard error) of a Gaussian KDE of ``x`` on ``grid``: unit area, and the pointwise
    error sqrt(f R(K) / (n_eff h)) with R(K) = 1 / (2 sqrt(pi)) for a Gaussian kernel of width h and
    n_eff = (sum w)^2 / sum w^2. ``bw`` is a width in x units, or 'scott' / 'silverman'."""
    from scipy.stats import gaussian_kde

    weights = None if weights is None else np.asarray(weights, dtype=float)
    try:
        width = float(bw)
    except (TypeError, ValueError):
        method = bw
    else:
        spread = np.sqrt(np.cov(x, aweights=weights)) if len(x) > 1 else 0.0
        method = width / spread if spread > 0 else "scott"
    kde = gaussian_kde(x, bw_method=method, weights=weights)
    density = kde(grid)
    h = float(np.sqrt(kde.covariance[0, 0]))
    n_eff = float(kde.neff)
    error = np.sqrt(np.clip(density, 0, None) / (2 * np.sqrt(np.pi)) / (n_eff * h))
    return density, error


def ecdf_curve(x, weights, grid=None):
    """(points, F, standard error) of the empirical CDF of ``x``: F at every sorted value (or on
    ``grid``), and the binomial error sqrt(F (1 - F) / n_eff)."""
    weights = np.ones_like(x, dtype=float) if weights is None else np.asarray(weights, dtype=float)
    order = np.argsort(x)
    xs, cumulative = x[order], np.cumsum(weights[order])
    total = cumulative[-1]
    n_eff = total**2 / float(np.sum(weights**2))
    if grid is None:
        points, fraction = xs, cumulative / total
    else:
        points = grid
        index = np.searchsorted(xs, grid, side="right")
        fraction = np.where(index > 0, cumulative[np.maximum(index - 1, 0)], 0.0) / total
    return points, fraction, np.sqrt(fraction * (1 - fraction) / n_eff)


def cumulate(counts, variance, weighted, density, reverse=False, cl=intervals.ONE_SIGMA):
    """--cumulative: the accumulated bin contents (``counts``, unnormalised) and their 2xN errors:
    Garwood intervals of the accumulated counts, or sqrt of the accumulated sum of squared weights
    (``variance``) when ``weighted``; with density, as fractions of the total."""
    if reverse:
        accumulate = lambda a: np.cumsum(np.asarray(a)[::-1])[::-1]  # noqa: E731
    else:
        accumulate = np.cumsum  # noqa: E731
    values = accumulate(counts)
    if weighted:
        spread = np.sqrt(accumulate(variance))
        errors = np.vstack([spread, spread])
    else:
        low, high = intervals.garwood(values, cl)
        errors = np.vstack([values - low, high - values])
    total = float(np.sum(counts))
    if density and total > 0:
        values, errors = values / total, errors / total
    return values, errors


def _draw_rug(ax, x, color):
    """--rug: a tick per value along the bottom of the axes, fainter the more there are."""
    if len(x) > RUG_MAX:
        rprint(f"\t--rug: {RUG_MAX} of {len(x)} values drawn (a random sample).")
        x = np.random.default_rng(0).choice(x, RUG_MAX, replace=False)
    alpha = float(np.clip(10 / np.sqrt(max(len(x), 1)), 0.05, 0.8))
    transform = blended_transform_factory(ax.transData, ax.transAxes)
    ax.vlines(x, 0, 0.04, transform=transform, color=color, alpha=alpha, linewidth=0.8, rasterized=True)


def _series_style(args, value, name):
    """(label, mapped colour or None, line style or None) of one hue value."""
    if args.iterable == "Config":
        label = make_config_label_from_args(args, config=value, name=name)
        color, linestyle = make_config_color_and_style_from_args(args, config=value, name=name)
        return label, color, linestyle
    label = None if value is None else f"{value}"
    color = None
    if args.iterable_mapping is not None:
        label = map_iterable_label(value, args.iterable, args.iterable_mapping)
    if args.iterable_color_mapping is not None:
        color = map_iterable_color(value, args.iterable_color_mapping) or color
    return label, color, None


def draw_figure(df, args, kdx, config, name):
    variables = args.variables if args.variables is not None else [None]
    n_panels = len(variables)
    fig, axes, _, _ = create_panels(n_panels, grid=False)
    ranges = {}  # panel -> histogram range (panels may have very different scales)

    if args.iterable is not None:
        # Only the hue values left by --variables/--select, so no panel warns about the others.
        values = list(filter_dataframe(df, args)[args.iterable].unique())
        if args.iterable_order:
            values = [v for v in args.iterable_order if v in values] + [v for v in values if v not in args.iterable_order]
    else:
        values = [None]
    data = {str(v) for v in (args.data_hue or [])}
    is_data = lambda value: value is not None and str(value) in data  # noqa: E731
    values = [v for v in values if is_data(v)] + [v for v in values if not is_data(v)]  # data first
    colors = ColorAllocator()
    # --hue_cmap: the hue values without a mapped colour on one colour map, explained by a colorbar.
    unmapped = [v for v in values if not is_data(v) and v is not None and _series_style(args, v, name)[1] is None]
    hue_cmap = HueColormap(unmapped, args.hue_cmap, args.hue_cmap_range) if args.hue_cmap and unmapped else None
    colors.reserve([v for v in values if not is_data(v)],
                   lambda value: _series_style(args, value, name)[1] or registered_color(args, args.iterable, value)
                   or (hue_cmap.color(value) if hue_cmap else None))
    avoid_registered(colors, args, args.iterable)
    density = args.density or args.labely == "Density"
    if args.rug and args.ridge is not None:
        rprint("[yellow]Warning:[/yellow] --rug is not drawn with --ridge.")
    ridge_ticks = {}  # panel -> (baselines, labels) of --ridge
    # A KDE is a density (unit area), unless histogram data points share its axes: then counts per bin.
    kde_density = density or args.hist_type != "kde" or not args.data_hue

    for idx, variable in enumerate(variables):
        ax = axes[idx]
        series = []  # (value, x, weights) of every hue drawn in this panel
        for jdx, value in enumerate(values):
            if args.iterable is not None and len(values) > 8 and args.reduce and jdx % 2 == 1:
                continue
            rows = df
            if variable is not None:
                rows = rows[rows["Variable"] == variable]
            if value is not None:
                rows = rows[rows[args.iterable] == value]
            subset = filter_dataframe(rows, args)
            if subset.empty:
                rprint(f"[yellow]Warning:[/yellow] No data for {args.iterable}={value}, Variable={variable}. Skipping.")
                continue
            weights = np.asarray(subset[args.weight].values[0], dtype=float) if args.weight is not None else None
            series.append((value, combined_values(subset, args), weights))
        if not series:
            continue
        ranges[idx] = _histogram_range([x for _, x, _ in series], args, idx)
        edges = np.histogram_bin_edges(ranges[idx], bins=args.bins, range=ranges[idx])  # the same edges for every hue

        rows_of_ridge = []  # (kind, x values, y values, errors, colour, data?) for --ridge
        for value, x, weights in series:
            label, mapped, linestyle = _series_style(args, value, name)
            color = (mapped or style.role("ink")) if is_data(value) else colors.color_for(value, mapped)
            curve_kind = "hist"
            if args.hist_type == "ecdf":
                curve_kind = "ecdf"
            elif args.hist_type == "kde" and not is_data(value):
                curve_kind = "kde"  # data stay points of a histogram
            if curve_kind == "hist":
                outside = int(np.sum(x < edges[0]) + np.sum(x > edges[-1]))
                if outside:
                    what = f"{args.iterable}={value}" if value is not None else "the sample"
                    rprint(f"[yellow]Warning:[/yellow] {outside} of {len(x)} entries of {what} (Variable={variable}) "
                           f"fall outside [{edges[0]:g}, {edges[-1]:g}] (--flow {args.flow}).")
                counts, under, over, errors = histogram_with_errors(x, edges, weights, density=density, flow=args.flow)
                centres = 0.5 * (edges[1:] + edges[:-1])
                show_errors = not args.no_error  # rule U1: a band on step histograms, bars on points
                if args.cumulative:
                    raw, _, _, spread = histogram_with_errors(x, edges, weights, density=False, flow=args.flow)
                    counts, errors = cumulate(raw, spread**2, weights is not None, density,
                                              reverse=args.cumulative == "reverse", cl=args.confidence_level)
                elif show_errors:
                    errors = bin_errors(x, edges, weights, density=density, flow=args.flow, cl=args.confidence_level)
                if args.ridge is not None:
                    rows_of_ridge.append(("hist", edges, counts, errors if show_errors else None, color, is_data(value),
                                          label))
                elif is_data(value):
                    ax.errorbar(centres, counts, yerr=errors if show_errors else None, fmt="o", color=color,
                                label=label, zorder=3)
                else:
                    ax.stairs(counts, edges, label=label, color=color, linestyle=_resolve_plot_style(linestyle) or "-",
                              linewidth=style.default_linewidth)
                    if show_errors and args.errory_type == "poisson":
                        ax.errorbar(centres, counts, yerr=errors, fmt="none", color=color, linewidth=1)
                    elif show_errors:
                        _draw_band(ax, counts, errors, edges, color)
                if args.flow == "hint" and args.ridge is None and not args.cumulative:
                    _draw_flow_hints(ax, counts, edges, under, over, color)
            elif curve_kind == "kde":
                grid = np.linspace(edges[0], edges[-1], 400)
                ys, errors = kde_curve(x, weights, grid, args.bw)
                if not kde_density:  # counts per bin, like the data points it is drawn with
                    scale = (float(np.sum(weights)) if weights is not None else len(x)) * float(np.mean(np.diff(edges)))
                    ys, errors = ys * scale, errors * scale
                if args.ridge is not None:
                    rows_of_ridge.append(("kde", grid, ys, None if args.no_error else errors, color, False, label))
                else:
                    ax.plot(grid, ys, color=color, linestyle=_resolve_plot_style(linestyle) or "-",
                            linewidth=style.default_linewidth, label=label)
                    if not args.no_error:
                        ax.fill_between(grid, ys - errors, ys + errors, color=color, alpha=0.2, linewidth=0)
            else:
                grid = np.linspace(edges[0], edges[-1], ECDF_POINTS) if len(x) > ECDF_POINTS else None
                points, ys, errors = ecdf_curve(x, weights, grid)
                if grid is None:  # exact steps, from 0 at the left edge
                    points = np.concatenate([[min(edges[0], points[0])], points])
                    ys, errors = np.concatenate([[0.0], ys]), np.concatenate([[0.0], errors])
                if args.ridge is not None:
                    rows_of_ridge.append(("ecdf", points, ys, None if args.no_error else errors, color, is_data(value),
                                          label))
                else:
                    ax.step(points, ys, where="post", color=color, linewidth=style.default_linewidth, label=label,
                            linestyle=_resolve_plot_style(linestyle) or "-", zorder=3 if is_data(value) else 2)
                    if not args.no_error:
                        ax.fill_between(points, ys - errors, ys + errors, step="post", color=color, alpha=0.2,
                                        linewidth=0)
            if args.rug and args.ridge is None:
                _draw_rug(ax, x, color)
        if rows_of_ridge:
            ridge_ticks[idx] = _draw_ridges(ax, rows_of_ridge, args.ridge)
        if args.overlay_gaussian is not None:
            _overlay_gaussian(ax, series[0], edges, density, args)

    data_labels = {_series_style(args, v, name)[0] for v in values if is_data(v)}
    is_data_label = lambda label: label in data_labels  # noqa: E731

    for idx, variable in enumerate(variables):
        ax = axes[idx]
        if n_panels > 1:
            title = args.panel_title[idx] if args.panel_title is not None else make_subtitle_from_args(args, None, idx=idx)
            ax.set_title(title, fontsize=style.subtitlefontsize)
        default_x = args.labelx if args.labelx is not None else " ".join(args.x)
        ax.set_xlabel(args.panel_labelx[idx] if args.panel_labelx is not None else resolve_axis_label(default_x, None, df))
        if idx in ridge_ticks:
            # Ridges: the hue values name the baselines; the height is only a shape.
            baselines, labels = ridge_ticks[idx]
            ax.set_yticks(baselines)
            ax.set_yticklabels(labels)
            ax.tick_params(axis="y", which="minor", left=False, right=False)
            if idx == 0 and args.labely is not None:
                ax.set_ylabel(args.labely)
        elif idx == 0:
            if args.hist_type == "ecdf":
                default_y = "Cumulative fraction"
            elif args.cumulative:
                default_y = "Cumulative fraction" if density else "Cumulative counts"
            else:
                default_y = "Density" if density or (args.hist_type == "kde" and kde_density) else "Counts"
            default_y = args.labely if args.labely is not None else default_y
            show = args.error_label if args.error_label is not None else style.error_label
            # The Garwood intervals of unweighted counts: on every histogram, or the data points over a KDE.
            if (show and args.weight is None and args.hist_type != "ecdf" and not args.cumulative
                    and not args.no_error and (args.hist_type == "hist" or args.data_hue)):
                default_y = f"{default_y}, {intervals.label('poisson', args.confidence_level)}"
            ax.set_ylabel(resolve_axis_label(default_y, None, df))
        rangex = panel_rangex(args, idx)
        if rangex is not None:
            ax.set_xlim(*rangex)
        elif args.rangex is None:
            ax.set_xlim(ranges.get(idx))
        else:
            ax.set_xlim(args.rangex[0], args.rangex[1])
        if args.rangey is not None and idx not in ridge_ticks:
            ax.set_ylim(args.rangey[0], args.rangey[1])
        apply_tick_formatter(ax, axis="x" if idx in ridge_ticks else "both")
        if args.logy:
            ax.semilogy()
        if args.logx:
            ax.semilogx()
        # A single series without --hue needs no legend (unless a Gaussian is drawn over it).
        if (idx == n_panels - 1 and (args.iterable is not None or args.overlay_gaussian is not None)
                and not args.no_legend and args.draw_legend != "none" and hue_cmap is None and not ridge_ticks):
            handles, labels = ax.get_legend_handles_labels()
            # matplotlib lists error bars after the steps: the data entries go first.
            order = sorted(range(len(labels)), key=lambda i: not is_data_label(labels[i]))
            apply_legend_style(ax, title=args.labelz or args.iterable, handles=[handles[i] for i in order],
                               labels=[labels[i] for i in order], capitalize_labels=args.capitalize_legend)
        draw_overlays(ax, args)
        draw_panel_lines(ax, args, idx)

    if hue_cmap is not None and not args.no_hue_colorbar:
        hue_cmap.colorbar(fig, list(axes[:n_panels]), label=args.labelz or args.iterable,
                          tick_labels=[str(_series_style(args, v, name)[0]) for v in hue_cmap.values])
    add_title_and_note(fig, args)
    return save(fig, args, kdx, suffix="hist.png")


def _draw_ridges(ax, rows, overlap):
    """--ridge: each row (kind, x, y, errors, colour, data?, label) on its own baseline, the first on
    top, scaled so the tallest curve reaches ``overlap`` into the row above. Simulation is filled at
    alpha 0.6 with its outline; data are ink points with their errors (an ink outline for an ECDF);
    a KDE keeps its band. Returns (baselines, labels) for the y ticks."""
    peak = max((float(np.nanmax(y)) for _, _, y, _, _, _, _ in rows), default=1.0)
    scale = (1 + overlap) / peak if peak > 0 else 1.0
    n = len(rows)
    baselines, labels = [], []
    for i, (kind, x, y, errors, color, data, label) in enumerate(rows):
        base = float(n - 1 - i)
        z = 2 + i * 0.01  # lower rows in front
        baselines.append(base)
        labels.append(label)
        top = base + scale * y
        if kind == "hist" and data:
            centres = 0.5 * (x[1:] + x[:-1])
            ax.errorbar(centres, top, yerr=None if errors is None else scale * errors, fmt="o", markersize=3,
                        color=color, zorder=z + 0.005)
            continue
        if kind == "hist":
            ax.stairs(top, x, baseline=base, fill=True, facecolor=to_rgba(color, 0.6), edgecolor=color,
                      linewidth=style.default_linewidth, zorder=z)
            if errors is not None:
                _draw_band(ax, scale * y, scale * errors, x, color, zorder=z + 0.005, offset=base)
            continue
        where = "post" if kind == "ecdf" else None
        face = "none" if data else to_rgba(color, 0.6)
        ax.fill_between(x, base, top, step=where, facecolor=face, edgecolor=color,
                        linewidth=style.default_linewidth, zorder=z)
        if errors is not None and kind == "kde":
            ax.fill_between(x, top - scale * errors, top + scale * errors, color=color, alpha=0.2, linewidth=0,
                            zorder=z + 0.005)
    ax.set_ylim(-0.1, n - 1 + 1 + overlap + 0.1)
    return baselines, labels


def _project_relative(path):
    """Relative file paths are read from the project root."""
    from pathlib import Path

    from ..project import load_project

    if path is None or Path(path).expanduser().is_absolute() or Path(path).exists():
        return path
    return str(load_project().root / path)


def run(args):
    if args.hue_cmap and args.hue_cmap not in matplotlib.colormaps:
        rprint(f"[red]Error:[/red] --hue_cmap: unknown colour map '{args.hue_cmap}' (e.g. viridis, plasma, cividis).")
        return []
    args.panel_vertical_file = _project_relative(args.panel_vertical_file)
    resolve_panel_lines(args, n_panels=len(args.variables) if args.variables is not None else None, unit="--variables entry")
    df = import_data(args)
    if df.empty:
        rprint("[yellow]Warning:[/yellow] No datafiles found. Exiting...")
        return []
    if args.variables is not None and "None" in args.variables and "Variable" in df.columns:
        df["Variable"] = df["Variable"].fillna("None")

    configs, names = prepare_import(args)
    configs = configs if configs is not None and args.iterable != "Config" else [None]
    names = names if names is not None and args.iterable != "Name" else [None]
    outputs = []
    for kdx, (config, name) in enumerate(zip(configs, names)):
        rprint(f"Plotting for Config: {config}, Name: {name}")
        rows = df
        if config is not None and args.iterable != "Config":
            rows = rows[rows["Config"] == config]
        if name is not None and args.iterable != "Name":
            rows = rows[rows["Name"] == name]
        outputs.append(draw_figure(rows, args, kdx, config, name))
    return outputs


# --- Legacy command lines ----------------------------------------------------------------


def _legacy_hist1d(tokens):
    from ..legacy import has, rename

    tokens = rename(tokens, {"--operation": "--hist_combine", "-p": "--percentile"})
    if not has(tokens, "--hist_combine"):
        tokens += ["--hist_combine", "subtract"]  # the old default, part of the output name
    if not has(tokens, "--labelx"):
        tokens += ["--labelx", r"Time ($\mu$s)"]
    if not has(tokens, "--labely"):
        tokens += ["--labely", "Density"]
    return tokens + ["--output_suffix", "hist1d.png"]


LEGACY = {"script_compare_hist1d": _legacy_hist1d}
