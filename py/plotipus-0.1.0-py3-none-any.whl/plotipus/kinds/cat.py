"""cat: one value per category.

Each row carries an array column (``-y``, e.g. counts) binned along another
array column (``--integrate_over``) and a categorical column (``-x``), or
one scalar ``-y`` per row (already integrated). The array is reduced to a
scalar per row (``--integral_mode integrate``: sum of
y times bin width; ``sum``: plain sum; optionally within
``--integration_range``); rows sharing a category are summed and errors add
in quadrature. One series per ``--hue`` value (colour and marker; one series without
``--hue``), one line style (or bar opacity) per ``--style`` value;
``--kind`` draws points joined by lines (line), bare points (point, dodged
side by side), stems ending in a point (lollipop) or dodged bars (bar;
``--stacked``: one stack per category). ``--kind box|violin|strip`` keep the
array cells as distributions instead: a category's rows are pooled and drawn
as a box, a violin or jittered points. Bar errors are a hatched band around the bar top, data
(``--data_hue``) are ink points with error bars. ``--orient h`` puts the
categories on the y axis (first on top), ``--sort`` orders them by their
total. Category labels are rotated only when they would overlap.
"""

import matplotlib.lines as mlines
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import to_rgba
from rich import print as rprint

from .. import intervals, style, uncertainty
from ..args import add_common_args, map_iterable_label, resolve_axis_label
from ..encodings import LINESTYLES
from ..io import import_data, prepare_import
from ..hue_colors import avoid_registered, hue_color
from ..palettes import ColorAllocator
from ..panels import add_title_and_note, create_panels, draw_horizontal_overlay, save
from ..plot import apply_legend_style, apply_legend_style_clear_of_data, draw_vertical_lines, plot_data
from ..selection import filter_dataframe
from . import _base

KIND = "cat"
MARKERS = ["o", "s", "^", "D", "v", "P", "X", "*"]
DISTRIBUTIONS = ("box", "violin", "strip")


def build_parser():
    parser = _base.make_parser(KIND, "One value per category of -x, one series per --hue value.")
    add_common_args(
        parser,
        [
            "datafile", "configs", "names", "variables", "iterable", "select", "save_values",
            "remove_value", "filename_select", "filename_suffix", "x", "y", "labelx", "labely", "logy",
            "rangey", "title", "output", "subfolder", "horizontal", "horizontal_label",
            "horizontal_style", "horizontal_color", "horizontal_label_pos", "note", "multiply", "debug", "errory",
            "no_error", "exact", "confidence_level",
        ],
        overrides={
            "datafile": {"required": True},
            "x": {"required": True, "help": "Categorical column (one position per value)"},
            "y": {"required": True, "help": "Array column reduced to one value per row (or a scalar per row)"},
            "iterable": {"help": "Column whose values become separate series (colour); without it, one series"},
            "errory": {"help": "Errors are drawn by default (the {y}Error column, in quadrature, else Garwood "
                       "intervals of integer counts); kept for old command lists"},
        },
    )
    add = parser.add_argument
    add("--kind", choices=["line", "point", "lollipop", "bar", *DISTRIBUTIONS], default="line",
        help="Points joined by lines, bare points, stems ending in a point (lollipop), or dodged bars; box, violin "
        "and strip keep each row's -y array as a distribution (rows of a category pooled) instead of summing it.")
    add("--orient", choices=["v", "h"], default="v",
        help="v: categories along x; h: categories along y, first on top (long labels, rankings). The value axis "
        "keeps --labely, --logy, --rangey and --horizontal.")
    add("--sort", choices=["asc", "desc"], default=None,
        help="Order the categories by their total over every series (box/violin/strip: the median of the pooled "
        "values; desc: largest first); replaces --x_order.")
    add("--whis", type=float, default=1.5,
        help="With --kind box: whisker reach in interquartile ranges (default 1.5).")
    add("--no_fliers", action="store_true", default=False, help="With --kind box: leave out the points past the whiskers.")
    add("--integrate_over", type=str, default=None,
        help="Array column with the bin centres of -y (default: bin index).")
    add("--integration_range", type=float, nargs=2, default=None, metavar=("LO", "HI"),
        help="Only bins whose --integrate_over value lies in [LO, HI].")
    add("--integral_mode", choices=["integrate", "sum"], default="integrate",
        help="'integrate' multiplies each bin by its width (densities -> totals); 'sum' adds raw values.")
    add("--comparable", "--style", "-c", dest="comparable", type=str, default=None,
        help="Column drawn with distinct line styles (bars: opacity).")
    add("--comparable_linestyles", nargs="+", type=str, default=None,
        help="Line styles cycled over the --comparable values (default - -- : -.).")
    add("--comparable_mapping", type=str, default=None, help="Mapping renaming the --comparable values.")
    add("--comparable_title", type=str, default=None, help="Heading of the --comparable legend section.")
    add("--iterable_mapping", "--hue_mapping", dest="iterable_mapping", type=str, default=None,
        help="Mapping renaming the hue values in the legend.")
    add("--iterable_color_mapping", "--hue_color_mapping", dest="iterable_color_mapping", type=str, default=None,
        help="Mapping giving the colour of each hue value.")
    add("--xtick_mapping", type=str, default=None, help="Mapping renaming the categories on the axis.")
    add("--x_order", nargs="+", type=str, default=None, help="Order of the categories (default: first seen).")
    add("--xtick_rotation", type=float, default=None, metavar="DEG",
        help="Rotate the category labels by DEG (default: 30 only when they would overlap; 20 is the old look).")
    add("--data_hue", "--overlay", nargs="+", default=None, metavar="VALUE",
        help="Hue values drawn as data: points with error bars (when the {y}Error column is there) in the "
        "ink colour at the category centre, first in the legend; the other hue values stay bars or lines.")
    add("--stacked", action="store_true", default=False,
        help="With --kind bar: stack the hue values in one bar per category, with a hatched band of the total's "
        "error (errors in quadrature, with --errory); --data_hue values stay points on top.")
    add("--overlay_names", action="store_true", default=False,
        help="All --configs/--names in one figure instead of one figure per pair.")
    _base.add_output_args(parser)
    return parser


def main(argv=None):
    return _base.main(__import__(__name__, fromlist=["run"]), argv)


def integrate_row(row, args, with_errors=None):
    """(value, error) of one row: -y reduced over --integrate_over, or a
    scalar -y (and {y}Error) taken as already integrated. Errors are read
    with --errory (or ``with_errors``)."""
    error_column = f"{args.y}Error"
    with_errors = args.errory if with_errors is None else with_errors
    if np.ndim(row[args.y]) == 0:
        value = float(row[args.y])
        error = None
        if with_errors and error_column in row.index and np.ndim(row[error_column]) == 0 and row[error_column] is not None:
            error = float(row[error_column])
        if args.multiply is not None:
            value *= args.multiply
            error = None if error is None else error * args.multiply
        return value, error
    y = np.asarray(row[args.y], dtype=float)
    yerr = None
    if with_errors and error_column in row.index and row[error_column] is not None:
        yerr = np.asarray(row[error_column], dtype=float)
    grid = row[args.integrate_over] if args.integrate_over and args.integrate_over in row.index else None
    grid = np.arange(len(y), dtype=float) if grid is None or np.ndim(grid) == 0 else np.asarray(grid, dtype=float)
    widths = np.gradient(grid) if args.integral_mode == "integrate" and len(grid) > 1 else np.ones_like(grid)

    mask = np.isfinite(y)
    if args.integration_range is not None:
        lo, hi = args.integration_range
        mask &= (grid >= lo) & (grid <= hi)
    value = float(np.sum(y[mask] * widths[mask]))
    error = float(np.sqrt(np.sum((yerr[mask] * widths[mask]) ** 2))) if yerr is not None and len(yerr) == len(y) else None
    if args.multiply is not None:
        value *= args.multiply
        error = None if error is None else error * args.multiply
    return value, error


def _ordered_unique(values, explicit=None):
    seen = list(dict.fromkeys(values))
    if explicit:
        return [v for v in explicit if v in seen] + [v for v in seen if v not in explicit]
    return seen


def _counted(row, args):
    """Whether the integrated value of ``row`` is itself a count: integer
    counts summed bin by bin (or one integer per row), not rescaled."""
    if args.multiply is not None or not uncertainty.is_counts(row[args.y]):
        return False
    if np.ndim(row[args.y]) == 0 or args.integral_mode == "sum":
        return True
    grid = row[args.integrate_over] if args.integrate_over and args.integrate_over in row.index else None
    return grid is None or np.ndim(grid) == 0 or bool(np.allclose(np.gradient(np.asarray(grid, dtype=float)), 1))


def _category_totals(subset, categories, positions, args, with_errors=None, name=None, hue=None):
    """(positions, totals, errors) of the categories present in ``subset``:
    rows of a category summed, errors (2xN, below and above) in quadrature,
    NaN without errors. Following the style guide's U1, a series without
    stored errors whose totals are counts gets Garwood intervals; ``counted``
    on the returned errors says so. Warnings name the series ``name``."""
    with_errors = args.errory if with_errors is None else with_errors
    if args.no_error or uncertainty.is_exact(args, hue):
        with_errors = False
    xs, ys, es = [], [], []
    stored, counted = False, True
    for position, category in zip(positions, categories):
        category_rows = subset[subset[args.x] == category]
        if category_rows.empty:
            continue
        totals = [integrate_row(row, args, with_errors) for _, row in category_rows.iterrows()]
        errors = [e for _, e in totals if e is not None]
        xs.append(position)
        ys.append(sum(v for v, _ in totals))
        error = float(np.sqrt(np.sum(np.square(errors)))) if errors else np.nan
        es.append((error, error))
        stored = stored or bool(errors)
        counted = counted and all(_counted(row, args) for _, row in category_rows.iterrows())
    xs, ys = np.asarray(xs), np.asarray(ys, dtype=float)
    es = np.asarray(es, dtype=float).T.reshape(2, len(xs))
    label = str(name) if name is not None else args.y
    counted = counted and with_errors and not stored and len(xs) > 0
    if counted:
        low, high = intervals.garwood(ys, args.confidence_level)
        es = np.vstack([np.clip(ys - low, 0, None), np.clip(high - ys, 0, None)])
        uncertainty.warn_interval(args, label, args.y, "poisson")
    elif with_errors and stored:
        uncertainty.check_bounds(args, label, f"{args.y}Error", ys, es[0], es[1])
    elif with_errors and len(xs):
        uncertainty.warn_none(args, label, args.y)
    return xs, ys, _Errors(es, counted)


class _Errors(np.ndarray):
    """2xN errors that remember whether they are Garwood intervals of counts."""

    def __new__(cls, values, counted=False):
        array = np.asarray(values, dtype=float).view(cls)
        array.counted = counted
        return array

    def __array_finalize__(self, other):
        self.counted = getattr(other, "counted", False)


def _sorted_categories(rows, categories, args):
    """--sort: the categories ordered by their total over every row (distribution kinds: the median of
    the pooled values; stable for ties)."""
    if args.kind in DISTRIBUTIONS:
        totals = {category: float(np.median(_pooled(rows[rows[args.x] == category], args)))
                  if len(_pooled(rows[rows[args.x] == category], args)) else -np.inf for category in categories}
    else:
        totals = {category: sum(integrate_row(row, args, with_errors=False)[0]
                                for _, row in rows[rows[args.x] == category].iterrows())
                  for category in categories}
    return sorted(categories, key=lambda c: totals[c], reverse=args.sort == "desc")


def _pooled(rows, args):
    """The finite -y values of ``rows``, every row's array (or scalar) pooled, scaled by --multiply."""
    parts = [np.ravel(np.asarray(value, dtype=float)) for value in rows[args.y]]
    values = np.concatenate(parts) if parts else np.array([])
    values = values[np.isfinite(values)]
    return values * args.multiply if args.multiply is not None else values


def _hue_values(rows, args):
    """The --hue column of ``rows``, or one empty value per row without --hue."""
    return rows[args.iterable] if args.iterable else pd.Series("", index=rows.index)


class _Axes:
    """Draws in (category position, value) coordinates on ``ax``, swapping x
    and y for --orient h."""

    def __init__(self, ax, horizontal):
        self.ax, self.horizontal = ax, horizontal

    def xy(self, positions, values):
        return (values, positions) if self.horizontal else (positions, values)

    def errorbar(self, positions, values, errors=None, **kwargs):
        x, y = self.xy(positions, values)
        key = "xerr" if self.horizontal else "yerr"
        return self.ax.errorbar(x, y, **{key: errors}, **kwargs)

    def bar(self, centres, values, width, bottom=None, **kwargs):
        if self.horizontal:
            return self.ax.barh(centres, values, height=width, left=bottom, **kwargs)
        return self.ax.bar(centres, values, width=width, bottom=bottom, **kwargs)

    def stems(self, positions, values, **kwargs):
        method = self.ax.hlines if self.horizontal else self.ax.vlines
        return method(positions, 0, values, **kwargs)

    def box(self, centre, low, high, width, **kwargs):
        """A rectangle spanning ``width`` around ``centre`` and [low, high] in value."""
        if self.horizontal:
            return mpatches.Rectangle((low, centre - width / 2), high - low, width, **kwargs)
        return mpatches.Rectangle((centre - width / 2, low), width, high - low, **kwargs)


def draw_figure(rows, args, kdx, comparable):
    categories = _ordered_unique(rows[args.x].tolist(), args.x_order)
    if args.sort:
        if args.x_order:
            rprint("[yellow]Warning:[/yellow] --sort orders the categories; --x_order is ignored.")
        categories = _sorted_categories(rows, categories, args)
    hue_values = _hue_values(rows, args)
    hues = _ordered_unique(hue_values.tolist())
    comparables = _ordered_unique(rows[comparable].dropna().tolist()) if comparable else [None]
    linestyles = args.comparable_linestyles or LINESTYLES
    positions = np.arange(len(categories), dtype=float)
    fig, axes, _, _ = create_panels(1)
    ax = axes[0]
    horizontal = args.orient == "h"
    draw = _Axes(ax, horizontal)

    data_values = {str(v) for v in (args.data_hue or [])}
    data_hues = [hue for hue in hues if str(hue) in data_values]
    models = [hue for hue in hues if str(hue) not in data_values]
    colors = ColorAllocator()
    colors.reserve(models, lambda hue: hue_color(hue, args, args.iterable))
    avoid_registered(colors, args, args.iterable)
    hue_handles, style_handles, data_handles, band_handles = [], [], [], []
    stacked = args.stacked and args.kind == "bar"
    # Points and lollipops side by side: each series its own slot within the category (data first).
    n_series = len(data_hues) + len(models)
    dodge = min(0.15, 0.6 / n_series) if args.kind in ("point", "lollipop") and n_series > 1 else 0.0

    def offset(slot):
        return (slot - (n_series - 1) / 2) * dodge

    if args.kind in DISTRIBUTIONS:
        if comparable:
            rprint(f"[yellow]Warning:[/yellow] --kind {args.kind} pools every --style value of a hue value.")
        data_hues, models, comparables = [], [], [None]
        hue_handles = _draw_distributions(draw, rows, hue_values, categories, positions, hues, data_values, colors, args)
    for ddx, hue in enumerate(data_hues):
        # Data: ink points with their errors at the category centre, first in the legend.
        subset = rows[hue_values == hue]
        xs, ys, es = _category_totals(subset, categories, positions, args, with_errors=True,
                                      name=map_iterable_label(hue, args.iterable, args.iterable_mapping), hue=hue)
        if not len(xs):
            continue
        draw.errorbar(xs + offset(ddx), ys, np.nan_to_num(es) if np.isfinite(es).any() else None, fmt="o",
                      color=style.role("ink"), zorder=3)
        data_handles.append(mlines.Line2D([], [], color=style.role("ink"), linestyle="none", marker="o",
                                          label=map_iterable_label(hue, args.iterable, args.iterable_mapping)))
    stack_bottom = np.zeros(len(categories))
    stack_variance = np.zeros((2, len(categories)))
    stack_has_errors, stack_counted = True, True
    for idx, hue in enumerate(models):
        # Hue values past the palette repeat a colour but keep their own marker.
        color = colors.color_for(hue)
        marker = MARKERS[idx % len(MARKERS)]
        hue_label = map_iterable_label(hue, args.iterable, args.iterable_mapping)
        if args.kind == "bar":
            hue_handles.append(mpatches.Patch(facecolor=color, alpha=0.9, label=hue_label))
        else:
            # Points and lollipops: the marker only; lines: a line with the marker.
            hue_handles.append(mlines.Line2D([], [], color=color, linestyle="-" if args.kind == "line" else "none",
                                             marker=marker, label=hue_label))
        for cdx, value in enumerate(comparables):
            subset = rows[hue_values == hue]
            if value is not None:
                subset = subset[subset[comparable] == value]
            if subset.empty:
                continue
            linestyle = linestyles[cdx % len(linestyles)]
            xs, ys, es = _category_totals(subset, categories, positions, args, name=hue_label, hue=hue)
            if not len(xs):
                continue
            rprint(f"\tValues for {args.iterable}={hue}" + (f", {comparable}={value}" if value is not None else "") + ": "
                   + ", ".join(f"{categories[int(i)]}={v:.3g}" for i, v in zip(xs, ys)))
            if stacked:
                slots = xs.astype(int)
                draw.bar(xs, ys, 0.8, bottom=stack_bottom[slots], color=color, alpha=0.9 if cdx == 0 else 0.5)
                stack_bottom[slots] += ys
                if args.errory and np.isfinite(es).all():
                    stack_variance[:, slots] += np.square(es)
                    stack_counted = stack_counted and es.counted
                else:
                    stack_has_errors = False
            elif args.kind == "bar":
                width = 0.8 / max(1, len(models))
                centres = xs + (idx - (len(models) - 1) / 2) * width
                draw.bar(centres, ys, width, color=color, alpha=0.9 if cdx == 0 else 0.5)
                if args.errory and np.isfinite(es).any():
                    band_handles[:] = [_error_band(draw, centres, ys, np.nan_to_num(es), width)]
            elif args.kind == "lollipop":
                # A thin, lighter stem from zero to the value, the value as the marker; the error bar runs
                # along the stem, so caps mark its ends.
                xs = xs + offset(len(data_hues) + idx)
                draw.stems(xs, ys, color=color, linewidth=style.default_linewidth / 2, linestyle=linestyle, alpha=0.6)
                errors = np.nan_to_num(es) if args.errory and np.isfinite(es).any() else None
                draw.errorbar(xs, ys, errors, color=color, marker=marker, linestyle="none", capsize=3, zorder=3)
            else:
                plot_type = "line" if args.kind == "line" else "scatter"
                # The series marker, as in the legend (points are drawn with fmt, default "o").
                kwargs = {"marker": marker} if args.kind == "line" else {"fmt": marker}
                xs = xs + offset(len(data_hues) + idx)
                if args.errory and np.isfinite(es).any():
                    draw.errorbar(xs, ys, np.nan_to_num(es), color=color, marker=marker,
                                  linestyle=linestyle if args.kind == "line" else "none", capsize=3)
                else:
                    px, py = draw.xy(xs, ys)
                    plot_data(args, ax, px, y=py, color=color, plot_type=plot_type, linestyle=linestyle, **kwargs)
            if value is not None and cdx >= len(style_handles):
                value_label = map_iterable_label(value, comparable, args.comparable_mapping)
                if args.kind == "bar":  # bars tell --style values apart by opacity
                    style_handles.append(mpatches.Patch(facecolor=style.role("ink"), alpha=0.9 if cdx == 0 else 0.5,
                                                        label=value_label))
                else:
                    style_handles.append(mlines.Line2D([], [], color=style.role("ink"), linestyle=linestyle,
                                                       label=value_label))

    if stacked and models and args.errory:
        if stack_has_errors:
            filled = stack_bottom > 0
            total = stack_bottom[filled]
            if stack_counted:  # a sum of counts is a count: its own Garwood interval
                low, high = intervals.garwood(total, args.confidence_level)
                errors = np.vstack([total - low, high - total])
            else:
                errors = np.sqrt(stack_variance[:, filled])
            band_handles = [_error_band(draw, positions[filled], total, errors, 0.8)]
        else:
            rprint("[yellow]Warning:[/yellow] The stack total error needs an error for every stacked value; "
                   "no band drawn.")

    tick_labels = [map_iterable_label(c, args.x, args.xtick_mapping) for c in categories]
    ylabel = args.labely
    if ylabel is None:
        unit_column = f"{args.y}Unit"
        unit = rows[unit_column].iloc[0] if unit_column in rows.columns else None
        if unit and args.integral_mode == "integrate" and "/ MeV" in str(unit):
            unit = str(unit).replace(" / MeV", "")
        scalar = all(np.ndim(value) == 0 for value in rows[args.y])  # already one value per row
        integrated = not scalar and args.kind not in DISTRIBUTIONS
        ylabel = ("Integrated " if integrated else "") + f"{args.y}" + (f" ({unit})" if unit else "")
    category_label = resolve_axis_label(args.labelx, args.x, rows)
    if horizontal:
        # Categories down the y axis, the first on top; the value axis is x.
        ax.set_yticks(positions)
        ax.set_yticklabels(tick_labels)
        ax.set_ylabel(category_label)
        ax.set_xlabel(ylabel)
        if args.logy:
            ax.set_xscale("log")
        if args.rangey is not None:
            ax.set_xlim(args.rangey)
        ax.set_ylim(len(categories) - 0.5, -0.5)
        draw_vertical_lines(ax, args.horizontal, labels=args.horizontal_label, styles=args.horizontal_style,
                            colors=args.horizontal_color, fontsize=style.linelabelfontsize)
    else:
        ax.set_xticks(positions)
        ax.set_xticklabels(tick_labels)
        ax.set_xlabel(category_label)
        ax.set_ylabel(ylabel)
        if args.logy:
            ax.set_yscale("log")
        if args.rangey is not None:
            ax.set_ylim(args.rangey)
        ax.set_xlim(-0.5, len(categories) - 0.5)
        draw_horizontal_overlay(ax, args)
        _rotate_tick_labels(fig, ax, args.xtick_rotation)  # the measured layout makes room for them

    # A stack lists its top first, as in line --stacked; the error band comes last.
    handles = data_handles + (hue_handles[::-1] if stacked else hue_handles) + band_handles
    if style_handles:
        title = args.comparable_title if args.comparable_title is not None else comparable
        handles.append(mlines.Line2D([], [], color="none", label=f"$\\bf{{{title}}}$" if title else ""))
        handles += style_handles
    if not args.iterable and not style_handles:
        pass  # one series without --hue: nothing to tell apart
    elif args.legend_loc:
        apply_legend_style(ax, handles=handles, capitalize_labels=args.capitalize_legend, loc=args.legend_loc)
    else:
        apply_legend_style_clear_of_data(ax, handles=handles, labels=[h.get_label() for h in handles],
                                         capitalize_labels=args.capitalize_legend)

    add_title_and_note(fig, args)
    return save(fig, args, kdx, suffix="cat.png")


def _draw_distributions(draw, rows, hue_values, categories, positions, hues, data_values, colors, args):
    """--kind box|violin|strip: the pooled -y values of every category x hue value, side by side within
    the category (only the hue values present share its width); returns the legend handles. Data
    (--data_hue) take the ink colour."""
    horizontal = draw.horizontal
    orientation = "horizontal" if horizontal else "vertical"
    def color_of(hue):
        return style.role("ink") if str(hue) in data_values else colors.color_for(hue)

    jitter = np.random.default_rng(0)  # the same strip on every run
    drawn = []
    for position, category in zip(positions, categories):
        in_category = rows[args.x] == category
        present = [(hue, _pooled(rows[in_category & (hue_values == hue)], args)) for hue in hues]
        present = [(hue, values) for hue, values in present if len(values) > (1 if args.kind == "violin" else 0)]
        width = 0.8 / max(1, len(present))
        for slot, (hue, values) in enumerate(present):
            centre = position + (slot - (len(present) - 1) / 2) * width
            color = color_of(hue)
            is_data = str(hue) in data_values
            if args.kind == "box":
                parts = plot_data(args, draw.ax, [centre], y=[values], plot_type="boxplot", color=color,
                                  positions=[centre], widths=[0.8 * width], whis=args.whis,
                                  showfliers=not args.no_fliers, manage_ticks=False, orientation=orientation)
                if is_data:  # data: a hollow ink outline, so they do not read as a filled simulation
                    for box in parts["boxes"]:
                        box.set_facecolor("none")
            elif args.kind == "violin":
                parts = plot_data(args, draw.ax, [centre], y=[values], plot_type="violin", color=color,
                                  positions=[centre], widths=[0.9 * width], orientation=orientation)
                if is_data:
                    for body in parts["bodies"]:
                        body.set_facecolor("none")
            else:
                # Jittered points, fainter the more there are; rasterised so a PDF stays small.
                spread = jitter.uniform(-0.35 * width, 0.35 * width, len(values))
                alpha = float(np.clip(15 / np.sqrt(len(values)), 0.03, 0.8))
                x, y = draw.xy(centre + spread, values)
                draw.ax.scatter(x, y, s=2, color=color, alpha=alpha, linewidths=0, rasterized=True)
            if hue not in drawn:
                drawn.append(hue)
            rprint(f"\t{args.x}={category}" + (f", {args.iterable}={hue}" if args.iterable else "")
                   + f": {len(values)} values, median {np.median(values):.3g}")
    handles = []
    data_first = sorted(drawn, key=lambda hue: (str(hue) not in data_values, hues.index(hue)))
    for hue in data_first:
        label = map_iterable_label(hue, args.iterable, args.iterable_mapping)
        color = color_of(hue)
        if args.kind == "strip":
            handles.append(mlines.Line2D([], [], color=color, linestyle="none", marker="o", label=label))
        else:
            face = "none" if str(hue) in data_values else to_rgba(color, 0.6)
            handles.append(mpatches.Patch(facecolor=face, edgecolor=color, label=label))
    return handles


def _error_band(draw, centres, values, errors, width):
    """Hatched boxes of ``values`` ± ``errors`` (N, or 2xN below and above)
    over bars of ``width`` at ``centres`` (the style's stack_error look;
    ``draw`` is the --orient helper); returns the legend handle."""
    band = style.role_colors(style.stack_error)
    hatch = band["hatch"] or None
    errors = np.asarray(errors, dtype=float)
    low, high = (errors, errors) if errors.ndim == 1 else (errors[0], errors[1])
    for centre, value, below, above in zip(centres, values, low, high):
        if below + above > 0:
            draw.ax.add_patch(draw.box(centre, value - below, value + above, width, fill=False, hatch=hatch,
                                       edgecolor=band["color"], linewidth=0, zorder=2.5))
    return mpatches.Patch(fill=False, hatch=hatch, edgecolor=band["color"], linewidth=0, label=band["label"])


def _rotate_tick_labels(fig, ax, rotation=None, pad_px=4):
    """Rotate the x tick labels by *rotation*, or, when any two would overlap,
    by 30 degrees (90 if they would still collide)."""
    labels = [label for label in ax.get_xticklabels() if label.get_text()]
    if labels:
        # At least half an em between labels: the layout may still narrow the axes a little.
        pad_px = max(pad_px, 0.5 * labels[0].get_fontsize() * fig.dpi / 72.0)
    if rotation is None:
        fig.canvas.draw()
        boxes = sorted((label.get_window_extent() for label in labels), key=lambda box: box.x0)
        rotation = 30 if any(a.x1 + pad_px > b.x0 for a, b in zip(boxes, boxes[1:])) else 0
        if rotation:
            # Rotated labels are parallel lines spacing * sin(angle) apart. The measured layout then
            # narrows the axes by however far the first label reaches past the figure's left edge,
            # and the spacing with them.
            centres = sorted((box.x0 + box.x1) / 2 for box in boxes)
            spacing = min(np.diff(centres)) if len(centres) > 1 else np.inf
            height = max(box.height for box in boxes)
            plt.setp(labels, rotation=30, ha="right", rotation_mode="anchor")
            fig.canvas.draw()
            width = ax.get_window_extent().width
            overflow = max(0.0, -min(label.get_window_extent().x0 for label in labels))
            spacing *= max(width - overflow, 0.0) / width
            if spacing * np.sin(np.radians(30)) < height + pad_px:
                rotation = 90
    if rotation:
        plt.setp(labels, rotation=rotation, ha="right", rotation_mode="anchor")


def run(args):
    # U1: errors are drawn by default; --errory only still names the file.
    args.errory_given = args.errory
    args.errory = not args.no_error
    df = import_data(args)
    if df.empty:
        rprint("[yellow]Warning:[/yellow] No datafiles found. Exiting...")
        return []
    for column in (args.x, args.y, args.iterable):
        if column is not None and column not in df.columns:
            rprint(f"[red]Error:[/red] Column '{column}' not found. Available: {', '.join(map(str, df.columns))}")
            return []
    comparable = args.comparable if args.comparable in df.columns else None
    if args.comparable is not None and comparable is None:
        rprint(f"[yellow]Warning:[/yellow] Column '{args.comparable}' not found; one series per hue value.")

    configs, names = prepare_import(args)
    pairs = list(zip(configs, names)) if configs is not None and not args.overlay_names else [(None, None)]
    outputs = []
    for kdx, (config, name) in enumerate(pairs):
        rows = df
        if config is not None:
            rows = rows[rows["Config"] == config]
        if name is not None:
            rows = rows[rows["Name"] == name]
        rows = filter_dataframe(rows, args)
        if args.iterable:
            rows = rows[rows[args.iterable].notna()]
        if rows.empty:
            rprint(f"[yellow]Warning:[/yellow] No data for Config={config}, Name={name}. Skipping.")
            continue
        outputs.append(draw_figure(rows, args, None if args.overlay_names else kdx, comparable))
    return outputs


# --- Legacy command lines ----------------------------------------------------------------


def _legacy_integral(tokens):
    from ..legacy import has, option_values, rename

    plot_type = (option_values(tokens, "--plot_type") or ["line"])[0]
    tokens = rename(tokens, {"--plot_type": None})
    tokens += ["--kind", {"scatter": "point"}.get(plot_type, plot_type)]
    if not has(tokens, "--integrate_over"):
        tokens += ["--integrate_over", "Energy"]
    return tokens + ["--output_suffix", "integral.png"]


LEGACY = {"script_compare_integral": _legacy_integral}
