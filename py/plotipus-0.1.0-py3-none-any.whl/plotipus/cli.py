"""``plotipus`` command line.

    plotipus <kind> [options]          draw one plot/table (kinds: line, scatter,
                                       hist, map, cat, table)
    plotipus run <list> [--tables]     run a command list (--dry_run, --check, --jobs N, --isolate,
                                       --medium slides|paper|web|all, --theme light|dark)
    plotipus translate <command...>    show the plotipus form of a legacy command
    plotipus init [directory]          create a project skeleton
    plotipus colors [COLUMN ...]       give every hue value of the project a colour of its own, kept in
                                       colors.json for every figure (--dry_run)
"""

import argparse
import shlex
import sys
from pathlib import Path

from . import __version__
from .legacy import KINDS, kind_module, translate

_TEMPLATE = """[project]
data_root = "input/data"
plots = "input/plots"
tables = "input/tables"
output = "output"
# style = ["config/style.json"]
# medium = "slides"            # slides | paper | web
# media = ["slides", "paper"]  # rendered by plotipus run (--medium all)
# theme = "light"              # light | dark
# plugins = ["my_plugin"]

# [outputs.plots]
# paper = ["../paper/figures"]
"""

_EXAMPLE_LIST = """# One plot per line: plotipus <kind> [options] without the 'plotipus'.
# line --datafile Example -x Energy -y Counts --hue Sample
"""


def _init(directory):
    root = Path(directory).resolve()
    for sub in ("input/data", "input/plots", "input/tables", "output/plots", "output/tables"):
        (root / sub).mkdir(parents=True, exist_ok=True)
    config = root / "plotipus.toml"
    if not config.exists():
        config.write_text(_TEMPLATE, encoding="utf-8")
    example = root / "input/plots/example_scripts.txt"
    if not example.exists():
        example.write_text(_EXAMPLE_LIST, encoding="utf-8")
    print(f"Project ready in {root}")
    return 0


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    if argv[0] in ("-V", "--version"):
        print(f"plotipus {__version__}")
        return 0

    command, rest = argv[0], argv[1:]
    if command == "run":
        parser = argparse.ArgumentParser(prog="plotipus run", description="Run a command list.")
        parser.add_argument("list", help="List name (<plots>/<list>_scripts.txt) or a .txt path")
        parser.add_argument("--tables", action="store_true", help="Look the list up in the tables directory")
        parser.add_argument("--show", action="store_true", help="Keep figures open")
        parser.add_argument("--debug", "-d", action="store_true")
        parser.add_argument("--jobs", "-j", type=int, default=1, help="Commands run in parallel")
        parser.add_argument("--dry_run", "--dry-run", action="store_true", help="Print the translated commands only")
        parser.add_argument("--match", type=str, default=None, help="Only commands containing this text")
        parser.add_argument("--check", action="store_true", help="Only check that every command parses")
        parser.add_argument("--medium", default=None, choices=["slides", "paper", "web", "all"],
                            help="Render every plot command for this medium ('all': [project] media); "
                            "default: [project] media, else [project] medium")
        parser.add_argument("--theme", default=None, choices=["light", "dark"], help="Theme of every plot command")
        parser.add_argument("--isolate", default=None, choices=["fork", "subprocess"],
                            help="Run each command in a fork of the preloaded runner (fork, the default where "
                            "available: no imports per command) or in a new Python (subprocess)")
        options = parser.parse_args(rest)
        from .runner import run_list

        failures = run_list(options.list, options.tables, options.show, options.debug, options.jobs,
                            options.dry_run, options.match, options.check, options.medium, options.theme,
                            options.isolate)
        return 1 if failures else 0
    if command == "translate":
        tokens = shlex.split(" ".join(rest)) if len(rest) == 1 else rest
        kind, args = translate(tokens)
        print("plotipus " + shlex.join([kind, *args]))
        return 0
    if command == "init":
        return _init(rest[0] if rest else ".")
    if command == "colors":
        parser = argparse.ArgumentParser(prog="plotipus colors", description=(
            "Give every hue value of the project's data a colour of its own in colors.json (rule C1): every "
            "figure then draws it in that colour. Values already there keep theirs."))
        parser.add_argument("columns", nargs="*", metavar="COLUMN",
                            help="Hue columns to register (default: the --hue columns of the plot command lists)")
        parser.add_argument("--dry_run", "--dry-run", action="store_true", help="Print the new colours only")
        options = parser.parse_args(rest)
        from .hue_colors import update

        update(options.columns, options.dry_run)
        return 0
    if command.endswith(".py"):
        kind, rest = translate(argv)
        command = kind
    if command in KINDS or command:
        module = kind_module(command)
        module.main(rest)
        return 0
    print(__doc__)
    return 2
